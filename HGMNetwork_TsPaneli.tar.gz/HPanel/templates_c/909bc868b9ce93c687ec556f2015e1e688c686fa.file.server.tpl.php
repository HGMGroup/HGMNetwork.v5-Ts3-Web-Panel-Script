<?php /* Smarty version Smarty3rc4, created on 2018-02-05 02:16:22
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/47/server.tpl" */ ?>
<?php /*%%SmartyHeaderCode:209535a77be76b7d221-74907417%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '909bc868b9ce93c687ec556f2015e1e688c686fa' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/47/server.tpl',
      1 => 1501881922,
    ),
  ),
  'nocache_hash' => '209535a77be76b7d221-74907417',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<script type="text/javascript">
	$(function () {
		var table = $("#server").DataTable({
			"language": {
				"url": dataTableLang
			},
			"order": [[ 0, "asc"]],
			"columnDefs": [
				{ targets: 'no-sort', orderable: false },
				{ targets: 'no-search', searchable: false }
			],
			"processing": true,
			initComplete: function() {
				var api = this.api();
				$('#server_processing').css('top', '7%');
				$('.pagination').addClass('pagination-flat');
			}
		});
		$('form').on('submit', function(e){
			$('input:disabled').prop('disabled', false);
		});
		$('#server_saction input[type="checkbox"]').on('change', function(){
			$.post({
				url: $('#server_saction').attr('action'),
				data: $('#server_saction').serialize(),
			})
		});
	});
</script>
<section class="content container-fluid">
	<div class="col-lg-10 col-lg-offset-1 no-padding">
		<?php if ($_smarty_tpl->getVariable('hoststatus')->value===false&&$_smarty_tpl->getVariable('serverhost')->value===true){?>
		<div class="alert alert-warning"><?php echo $_smarty_tpl->getVariable('lang')->value['nohoster'];?>
</div>
		<?php }else{ ?>
		<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
		<?php }?>
		<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
		<?php }?>
		<div class="box box-border-teal" data-name="server_msgtoall">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['msgtoall'];?>
</h3>
				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
				</div>
			</div>
			<form class="box-body" method="post" action="index.php?site=server">
				<div class="form-group">
					<textarea type="text" class="form-control resize-vert" name="msgtoall" id="msgtoall"></textarea>
				</div>
				<input class="btn btn-flat bg-teal pull-right" type="submit" name="sendmsg" value="<?php echo $_smarty_tpl->getVariable('lang')->value['send'];?>
" />
			</form>
		</div>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
</h3>
			</div>
			<form class="box-body" method="post" id="server_saction" action="index.php?site=server">
				<input type="hidden" name="massaction" />
				<?php if (!empty($_smarty_tpl->getVariable('serverlist')->value)){?><p><?php echo $_smarty_tpl->getVariable('serverstats')->value;?>
</p><?php }?>
				<table id="server" class="table table-striped table-td-no-padding">
					<thead>
						<tr>
							<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['id'];?>
 </th>
							<th><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
</th>
							<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['port'];?>
 </th>
							<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['status'];?>
 </th>
							<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['runtime'];?>
 </th>
							<th class="no-search text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
 </th>
							<th class="no-search text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['autostart'];?>
</th>
							<th class="no-sort"></th>
						</tr>
					</thead>
					<thead>
						<?php if (!empty($_smarty_tpl->getVariable('serverlist')->value)){?>
						<tr>
							<td colspan="7"></td>
							<td class="no-padding">
								<input class="btn btn-flat btn-sm btn-primary btn-block" type="submit" value="<?php echo $_smarty_tpl->getVariable('lang')->value['action'];?>
" onclick="return confirm(confirm_action())" />
							</td>
						</tr>
						<?php }?>
					</thead>
					<tbody>

						<?php if (!empty($_smarty_tpl->getVariable('serverlist')->value)){?>
					<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('serverlist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
						<tr>
							<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
</td>
							<td style="vertical-align: middle;">
								<a href="index.php?site=serverview&amp;sid=<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_name'];?>
</a>
							</td>
							<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_port'];?>
</td>
							<td style="vertical-align: middle;" class="text-center">
							<?php if ($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="online"){?>
								<span class="btn btn-flat btn-xs btn-success disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['online'];?>
</span>
							<?php }elseif($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="online virtual"){?>
								<span class="btn btn-flat btn-xs btn-primary disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['onlinevirtual'];?>
</span>
							<?php }elseif($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="offline"){?>
								<span class="btn btn-flat btn-xs btn-danger disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['offline'];?>
</span>
							<?php }?>
							</td>
							<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_uptime'];?>
</td>
							<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_clientsonline'];?>
 / <?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_maxclients'];?>
</td>
							<td style="vertical-align: middle;" class="text-center"><input type="checkbox" name="caction[<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
][auto]" value="1" <?php if ($_smarty_tpl->tpl_vars['value']->value['virtualserver_autostart']==1){?>checked<?php }?> <?php if ($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="offline"){?>disabled<?php }?>/></td>
							<td style="vertical-align: middle;" class="text-right no-padding">
								<select class="form-control" id="caction<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
" name="caction[<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
][action]" onchange="confirm_array('<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
', '<?php echo addslashes($_smarty_tpl->tpl_vars['value']->value['virtualserver_name']);?>
', '<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_port'];?>
', '');" style="width: 100%;">
									<option value="false"><?php echo $_smarty_tpl->getVariable('lang')->value['select'];?>
</option>
									<option value="start"><?php echo $_smarty_tpl->getVariable('lang')->value['start'];?>
</option>
									<option value="stop"><?php echo $_smarty_tpl->getVariable('lang')->value['stop'];?>
</option>
									<option value="del"><?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
</option>
								</select>
							</td>
						</tr>
					<?php }} ?>
						<?php }else{ ?>
						<tr><td colspan='8'><p class="lead text-center no-margin"><?php echo $_smarty_tpl->getVariable('lang')->value['noserver'];?>
</p></td></tr>
						<?php }?>
					</tbody>
					<tfoot>
						<tr>
							<td colspan="7"></td>
							<td class="no-padding">
								<input class="btn btn-flat btn-sm btn-primary btn-block" type="submit" value="<?php echo $_smarty_tpl->getVariable('lang')->value['action'];?>
" onclick="return confirm(confirm_action())" />
							</td>
						</tr>						
					</tfoot>
				</table>
			</form>
		</div>
		<?php }?>
	</div>
</section>