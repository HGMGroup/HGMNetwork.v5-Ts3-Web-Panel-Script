<?php /* Smarty version Smarty3rc4, created on 2018-02-05 10:01:09
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/mrstipfan/logview.tpl" */ ?>
<?php /*%%SmartyHeaderCode:218285a782b6550a6e9-80204775%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b22b7f16ab329badb86654c7aab2add0f3a0557c' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/mrstipfan/logview.tpl',
      1 => 1513634812,
    ),
  ),
  'nocache_hash' => '218285a782b6550a6e9-80204775',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_log_view'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_log_view'])){?>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
			<div class="box box-danger">
				<div class="box-header"><h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
</h3></div>
				<div class="box-body">
					<p class="lead"><?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php }else{ ?>
<script>
	$(function () {
		var table = $("#traffic").DataTable({
			"language": {
				"url": dataTableLang
			},
            "autoWidth": false,
			"order": [[ 0, "desc" ]],
			"columnDefs": [
				{ targets: 0, responsivePriority: 1},
				{ targets: 4, responsivePriority: 2},
				{ targets: 'no-sort', orderable: false },
				{ targets: 'no-search', searchable: false }
			],
			"processing": true,
			initComplete: function() {
				var api = this.api();

				new $.fn.dataTable.Buttons(api, {
					"buttons": [
						{
							text: "<?php echo $_smarty_tpl->getVariable('lang')->value['showmoreentrys'];?>
",
							className: "btn btn-primary btn-flat btn_showmoreentrys",
							action: function ( e, dt, node, config ) {
								add_entries();
							}
						}
					]
				});

				$('#traffic_length').parent('.col-sm-6').removeClass('col-sm-6').addClass('col-sm-6 col-md-4');
				$('#traffic_filter').parent('.col-sm-6').removeClass('col-sm-6').addClass('col-sm-6 col-md-4 col-md-push-4').after('<div class="col-sm-12 col-md-4 col-md-pull-4 text-center"><div id="traffic_buttons"></div></div>');		
				$('#traffic_processing').css('top', '7%');
				$('.pagination').addClass('pagination-flat');
				api.buttons().container().prependTo( '#traffic_buttons' );
				$('#traffic_wrapper .row:eq(0) .col-sm-4')
			}
		});
		
		$(window).resize(function(){
	        $("#traffic").css('width', '100%');
	        $("#traffic").DataTable().columns.adjust().draw();
		});

		function add_entries(){
			var begin_pos = $('#begin_pos').val();
			var url = "index.php?site=logview&sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
";
			table.processing(true);
			$('.btn_showmoreentrys').addClass('disabled');
		
		
			$.post(url, {begin_pos: begin_pos }, function(data){
		
				data = $.parseHTML(data);
				$.each(data, function(key, itm){
					if (itm.className == 'wrapper') {
						var base = itm.children[2].children[0].children[0].children[0];
						var elems = base.children[0].children[1].children[1].children;
						var lastID = elems.length - 1;
						$.each(elems, function(uKey, uItm){
							console.log(uKey);
							table.row.add( [
								uItm.children[0].innerText,
								uItm.children[1].innerText,
								uItm.children[2].innerText,
								uItm.children[3].innerText,
								uItm.children[4].innerText
							] ).draw( false );
							if (uKey == lastID) {
								$('#begin_pos').val(base.children[0].children[0].value);
								$('.btn_showmoreentrys').removeClass('disabled');
								table.processing( false );
							}
						});
					}
				});
			});
		}
	});
</script>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1">
			<div class="box box-primary">
				<div class="box-body" id="main_content">
					<input type="hidden" id="begin_pos" name="begin_pos" value="<?php echo $_smarty_tpl->getVariable('begin_pos')->value;?>
"/>
					<table class="table table-striped dt-responsive" id="traffic">
						<thead>
							<tr>
								<th width="20%"><?php echo $_smarty_tpl->getVariable('lang')->value['date'];?>
</th>
								<th width="5%"><?php echo $_smarty_tpl->getVariable('lang')->value['level'];?>
</th>
								<th width="10%"><?php echo $_smarty_tpl->getVariable('lang')->value['type'];?>
</th>
								<th width="10%"><?php echo $_smarty_tpl->getVariable('lang')->value['serverid'];?>
</th>
								<th width="55%"><?php echo $_smarty_tpl->getVariable('lang')->value['message'];?>
</th>
							</tr>
						</thead>
						<tbody>
					<?php if (!empty($_smarty_tpl->getVariable('serverlog')->value)){?>
						<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('serverlog')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
							<?php if (empty($_POST['type']['error'])&&empty($_POST['type']['warning'])&&empty($_POST['type']['debug'])&&empty($_POST['type']['info'])||$_POST['type']['error']==$_smarty_tpl->tpl_vars['value']->value['level']||$_POST['type']['warning']==$_smarty_tpl->tpl_vars['value']->value['level']||$_POST['type']['debug']==$_smarty_tpl->tpl_vars['value']->value['level']||$_POST['type']['info']==$_smarty_tpl->tpl_vars['value']->value['level']){?>
								<tr>
									<td><?php echo $_smarty_tpl->tpl_vars['value']->value[0];?>
</td>
									<td><?php echo $_smarty_tpl->tpl_vars['value']->value[1];?>
</td>
									<td><?php echo $_smarty_tpl->tpl_vars['value']->value[2];?>
</td>
									<td><?php echo $_smarty_tpl->tpl_vars['value']->value[3];?>
</td>
									<td><?php echo $_smarty_tpl->tpl_vars['value']->value[4];?>
</td>
								</tr>
							<?php }?>
						<?php }} ?>
					<?php }?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>
<?php }?>