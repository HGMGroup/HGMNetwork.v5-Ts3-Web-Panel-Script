<?php /* Smarty version Smarty3rc4, created on 2020-04-22 01:14:43
         compiled from "C:\xampp\htdocs\htdocs\templates/mrstipfan/iserverbackup.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5099371905e9f7e6393f977-53667173%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2ffcd0e6015e0e57c3fb877703036c03de1ae8e3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\htdocs\\templates/mrstipfan/iserverbackup.tpl',
      1 => 1517828591,
    ),
  ),
  'nocache_hash' => '5099371905e9f7e6393f977-53667173',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include 'C:\xampp\htdocs\htdocs\libs\Smarty\libs\plugins\modifier.date_format.php';
?><section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
	<?php if ($_smarty_tpl->getVariable('hoststatus')->value===false&&$_smarty_tpl->getVariable('serverhost')->value===true){?>
		<div class="alert alert-warning"><?php echo $_smarty_tpl->getVariable('lang')->value['nohoster'];?>
</div>
	<?php }else{ ?>
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
	<?php }?>
		<div class="box box-warning">
			<div class="box-body">
				<p><?php echo $_smarty_tpl->getVariable('lang')->value['snapwarning'];?>
</p>
				<p><?php echo $_smarty_tpl->getVariable('lang')->value['serverbackups'];?>
</p>
				<p><?php echo $_smarty_tpl->getVariable('lang')->value['servbackdesc'];?>
</p>
			</div>	
		</div>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['instancebackup'];?>
</h3>
			</div>
			<div class="box-body">
				<table class="table table-striped">
					<tr>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['created'];?>
</th>
					<?php if (isset($_smarty_tpl->getVariable('files')->value[0])&&!empty($_smarty_tpl->getVariable('files')->value[0])||isset($_smarty_tpl->getVariable('folder')->value[2])&&!empty($_smarty_tpl->getVariable('folder')->value[2])){?>
						<?php if (isset($_POST['backupdate'])){?>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
</th>
						<?php }?>
						<th></th>
					<?php }else{ ?>
						<th></th>
					<?php }?>
					</tr>
					<?php if (isset($_smarty_tpl->getVariable('files')->value[0])&&!empty($_smarty_tpl->getVariable('files')->value[0])||isset($_smarty_tpl->getVariable('folder')->value[2])&&!empty($_smarty_tpl->getVariable('folder')->value[2])){?>
						<?php if (!isset($_POST['backupdate'])){?>
							<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('folder')->value[2]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<tr>
						<td style="vertical-align: middle; width: 50%" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value;?>
</td>
						<td style="vertical-align: middle;" colspan="2" class="no-padding text-center">
							<form method="post" action="index.php?site=iserverbackup">
								<input type="hidden" name="backupdate" value="<?php echo $_smarty_tpl->tpl_vars['value']->value;?>
" />
								<input class="btn btn-flat btn-sm btn-success" type="submit" name="chose" value="Geri Yükle" />
							</form>
						</td>
					</tr>
						<?php }} ?>
					<?php }else{ ?>
						<?php if (isset($_smarty_tpl->getVariable('files')->value[0])){?>
							<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('files')->value[0]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<tr>
						<td style="vertical-align: middle; width: 30%;" class="text-center"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['timestamp'],"%d.%m.%Y - %H:%M:%S");?>
</td>
						<td style="vertical-align: middle; width: 20%;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
</td>
						<td style="vertical-align: middle;" class="no-padding">
							<form method="post" class="no-margin no-padding col-md-9" action="index.php?site=iserverbackup">
								<div class="no-margin no-padding col-md-8">
									<select name="deployon" class="form-control">
										<option disabled selected>-</option>
										<?php if (!empty($_smarty_tpl->getVariable('serverlist')->value)){?>
											<?php  $_smarty_tpl->tpl_vars['value2'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key2'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('serverlist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value2']->key => $_smarty_tpl->tpl_vars['value2']->value){
 $_smarty_tpl->tpl_vars['key2']->value = $_smarty_tpl->tpl_vars['value2']->key;
?>
												<option value="<?php echo $_smarty_tpl->tpl_vars['value2']->value['virtualserver_port'];?>
"><?php echo $_smarty_tpl->tpl_vars['value2']->value['virtualserver_name'];?>
:<?php echo $_smarty_tpl->tpl_vars['value2']->value['virtualserver_port'];?>
</option>
											<?php }} ?>
										<?php }?>
									</select>
								</div>
								<div class="no-margin no-padding col-md-4">
									<input type="hidden" name="backupid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
" />
									<input type="hidden" name="fileport" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
" />
									<input type="hidden" name="backupdate" value="<?php echo $_POST['backupdate'];?>
" />
									<input class="btn btn-flat btn-block btn-success" type="submit" name="deploy" value="<?php echo $_smarty_tpl->getVariable('lang')->value['deploy'];?>
" />
								</div>
							</form>
							<form method="post" class="no-margin no-padding col-md-3" action="index.php?site=iserverbackup">
								<input type="hidden" name="backupid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
" />
								<input type="hidden" name="fileport" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
" />
								<input type="hidden" name="backupdate" value="<?php echo $_POST['backupdate'];?>
" />
								<input class="btn btn-flat btn-block btn-danger" type="submit" name="delete" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" />
							</form>
						</td>
					</tr>
						<?php }} ?>	
					<?php }else{ ?>
					<tr>
						<td colspan="3" class="text-center"><p class="lead no-margin">Yedek bulunamadı!</p></td>
					</tr>
					<?php }?>
						<?php }?>
					<?php }else{ ?>
					<tr>
						<td colspan="3" class="text-center"><p class="lead no-margin">Yedek bulunamadı!</p></td>
					</tr>
					<?php }?>
				</table>
			</div>
		</div>
		<div class="box box-info">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['host'];?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['serverbackups'];?>
</h3>
			</div>
			<div class="box-body">
				<table class="table table-striped">
					<tr>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['created'];?>
</th>
						<?php if (isset($_smarty_tpl->getVariable('files')->value[1])&&!empty($_smarty_tpl->getVariable('files')->value[1])||isset($_smarty_tpl->getVariable('folder')->value[1])&&!empty($_smarty_tpl->getVariable('folder')->value[1])){?>
							<?php if (isset($_POST['backupdate'])){?>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
</th>
							<?php }?>
						<th></th>
						<?php }else{ ?>
						<th></th>
						<?php }?>
					</tr>
					<?php if (isset($_smarty_tpl->getVariable('files')->value[1])&&!empty($_smarty_tpl->getVariable('files')->value[1])||isset($_smarty_tpl->getVariable('folder')->value[1])&&!empty($_smarty_tpl->getVariable('folder')->value[1])){?>
						<?php if (!isset($_POST['backupdate'])){?>
							<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('folder')->value[1]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<tr>
						<td style="vertical-align: middle; width: 50%;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value;?>
</td>
						<td style="vertical-align: middle;" colspan="2" class="no-padding text-center">
							<form method="post" action="index.php?site=iserverbackup">
								<input type="hidden" name="backupdate" value="<?php echo $_smarty_tpl->tpl_vars['value']->value;?>
" />
								<input class="btn btn-flat btn-sm btn-success" type="submit" name="chose" value="Geri Yükle" />
							</form>
						</td>
					</tr>
						<?php }} ?>
					<?php }else{ ?>
						<?php if (isset($_smarty_tpl->getVariable('files')->value[1])){?>
							<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('files')->value[1]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<tr>
						<td style="vertical-align: middle; width: 30%;" class="text-center"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['timestamp'],"%d.%m.%Y - %H:%M:%S");?>
</td>
						<td style="vertical-align: middle; width: 20%;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
</td>
						<td style="vertical-align: middle;" class="no-padding">
							<form method="post" class="no-margin no-padding col-md-9" action="index.php?site=iserverbackup">
								<div class="no-margin no-padding col-md-8">
									<select name="deployon" class="form-control">
										<option disabled selected>-</option>
								<?php if (!empty($_smarty_tpl->getVariable('serverlist')->value)){?>
									<?php  $_smarty_tpl->tpl_vars['value2'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key2'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('serverlist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value2']->key => $_smarty_tpl->tpl_vars['value2']->value){
 $_smarty_tpl->tpl_vars['key2']->value = $_smarty_tpl->tpl_vars['value2']->key;
?>
										<option value="<?php echo $_smarty_tpl->tpl_vars['value2']->value['virtualserver_port'];?>
"><?php echo $_smarty_tpl->tpl_vars['value2']->value['virtualserver_name'];?>
:<?php echo $_smarty_tpl->tpl_vars['value2']->value['virtualserver_port'];?>
</option>
									<?php }} ?>
								<?php }?>
									</select>
								</div>
								<div class="no-margin no-padding col-md-4">
									<input type="hidden" name="hostbackup" value="1" />
									<input type="hidden" name="backupdate" value="<?php echo $_POST['backupdate'];?>
" />
									<input type="hidden" name="backupid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
" />
									<input type="hidden" name="fileport" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
" />
									<input class="btn btn-flat btn-block btn-success pull-right" type="submit" name="deploy" value="<?php echo $_smarty_tpl->getVariable('lang')->value['deploy'];?>
" />
								</div>
							</form>
							<form method="post" class="no-margin no-padding col-md-3" action="index.php?site=iserverbackup">
								<input type="hidden" name="hostbackup" value="1" />
								<input type="hidden" name="backupdate" value="<?php echo $_POST['backupdate'];?>
" />
								<input type="hidden" name="backupid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
" />
								<input type="hidden" name="fileport" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
" />
								<input class="btn btn-flat btn-block btn-danger" type="submit" name="delete" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" />
							</form>
						</td>
					</tr>
						<?php }} ?>
					<?php }else{ ?>
					<tr>
						<td colspan="3" class="text-center"><p class="lead no-margin">Yedek bulunamadı!</p></td>
					</tr>
							<?php }?>
						<?php }?>
					<?php }else{ ?>
					<tr>
						<td colspan="3" class="text-center"><p class="lead no-margin">Yedek bulunamadı!</p></td>
					</tr>
					<?php }?>
				</table>
			</div>
		</div>
		<div class="box box-success">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['createserverbackup'];?>
</h3>
			</div>
			<div class="box-body">
				<br />
				<div class="row">
					<div class="col-md-6">
						<form method="post" action="index.php?site=iserverbackup">
							<input class="btn btn-flat btn-primary btn-block" type="submit" name="create" value="<?php echo $_smarty_tpl->getVariable('lang')->value['create'];?>
" />
						</form>
					</div>
					<?php if ($_smarty_tpl->getVariable('hoststatus')->value==true){?>
					<div class="col-md-6">
						<form method="post" action="index.php?site=iserverbackup">
							<input type="hidden" name="hostbackup" value="1" />
							<input class="btn btn-flat btn-info btn-block" type="submit" name="create" value="<?php echo $_smarty_tpl->getVariable('lang')->value['host'];?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['create'];?>
" />
						</form>
					</div>
					<?php }?>
				</div>
			</div>
		</div>
	<?php }?>
	</div>
</section>