<?php /* Smarty version Smarty3rc4, created on 2018-02-05 02:15:35
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/46/mainbar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:206975a77be4788caf7-62017271%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '05e7f404842a3c5cc8250a977039fb902bc34a90' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/46/mainbar.tpl',
      1 => 1501419068,
    ),
  ),
  'nocache_hash' => '206975a77be4788caf7-62017271',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_smarty_tpl->getVariable('loginstatus')->value===true){?>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
</li>
<?php if ($_smarty_tpl->getVariable('hoststatus')->value===true){?>
	<li><a href="index.php?site=server"><i class="mdi mdi-server mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['serverlist'];?>
</span></a></li>
<?php }?>
<?php if (!isset($_smarty_tpl->getVariable('sid')->value)&&$_smarty_tpl->getVariable('hoststatus')->value===true){?>
	<li><a href="index.php?site=createserver"><i class="mdi mdi-server-plus mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['createserver'];?>
</a></li>
	<li><a href="index.php?site=servertraffic"><i class="mdi mdi-server-network mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['instancetraffic'];?>
</a></li>
	<li><a href="index.php?site=instanceedit"><i class="mdi mdi-pencil mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['instanceedit'];?>
</a></li>
	<li><a href="index.php?site=logview"><i class="mdi mdi-format-list-bulleted mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['logview'];?>
</a></li>
	<li><a href="index.php?site=iserverbackup"><i class="mdi mdi-backup-restore mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['instancebackup'];?>
</a></li>
<?php }?>
<?php if (isset($_smarty_tpl->getVariable('sid')->value)){?>
	<li><a href="index.php?site=serverview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-information-variant mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['serverview'];?>
</a></li>
	<li><a href="index.php?site=servertraffic&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-server-network mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['virtualtraffic'];?>
</a></li>
	<li><a href="index.php?site=serveredit&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-server-edit mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['serveredit'];?>
</a></li>
	<li><a href="index.php?site=temppw&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-lock mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['temppw'];?>
</a></li>
	<li><a href="index.php?site=fileupload&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-upload mdi-lg"></i><?php echo $_smarty_tpl->getVariable('lang')->value['iconupload'];?>
</a></li>
	<li><a href="index.php?site=logview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-format-list-bulleted mdi-lg"></i><?php echo $_smarty_tpl->getVariable('lang')->value['logview'];?>
</a></li>
	<li><a href="index.php?site=filelist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-file-multiple mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['filelist'];?>
</a></li>
	<li><a href="javascript:oeffnefenster('site/interactive.php?sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;action=action', '<?php echo $_smarty_tpl->getVariable('lang')->value['massaction'];?>
');"><i class="mdi mdi-checkbox-multiple-marked mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['massaction'];?>
</a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
</li>
	<li><a href="index.php?site=channel&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-comment-multiple-outline mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['channellist'];?>
</a></li>
<?php if (isset($_smarty_tpl->getVariable('cid')->value)){?>
	<li><a href="index.php?site=channelview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cid=<?php echo $_smarty_tpl->getVariable('cid')->value;?>
"><i class="mdi mdi-comment-alert-outline mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['channelview'];?>
</a></li>
<?php }?>
<?php if (isset($_smarty_tpl->getVariable('cid')->value)){?>
	<li><a href="index.php?site=channeledit&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cid=<?php echo $_smarty_tpl->getVariable('cid')->value;?>
"><i class="mdi mdi-comment-processing-outline mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['channeledit'];?>
</a></li>
<?php }?>
	<li><a href="index.php?site=createchannel&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-comment-plus-outline mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['createchannel'];?>
</a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
</li>
	<li><a href="index.php?site=counter&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-multiple-star mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['clientcounter'];?>
</a></li>
	<li><a href="index.php?site=clients&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-multiple mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['clientlist'];?>
</a></li>
	<li><a href="index.php?site=complainlist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-alert mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['complainlist'];?>
</a></li>
	<li><a href="index.php?site=chanclienteditperm&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-comment-account-outline mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['chanclientperms'];?>
</a></li>
	<li><a href="index.php?site=clientcleaner&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-multiple-minus mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['clientcleaner'];?>
</a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['bans'];?>
</li>
	<li><a href="index.php?site=banlist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-multiple-off mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['banlist'];?>
</a></li>
	<li><a href="index.php?site=banadd&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-off-plus mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['addban'];?>
</a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['groups'];?>
</li>
	<li><a href="index.php?site=sgroups&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-server-account mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['servergroups'];?>
</a></li>
	<li><a href="index.php?site=sgroupadd&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-server-account-plus mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['addservergroup'];?>
</a></li>
	<li><a href="index.php?site=cgroups&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-comment-multiple-account-outline mdi-lg"></i><?php echo $_smarty_tpl->getVariable('lang')->value['channelgroups'];?>
</a></li>
	<li><a href="index.php?site=cgroupadd&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-comment-multiple-account-plus-outline mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['addchannelgroup'];?>
</a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['token'];?>
</li>
	<li><a href="index.php?site=token&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-key-variant mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['token'];?>
</a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['backup'];?>
</li>
	<li><a href="index.php?site=backup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-comment-download-outline mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['chanbackups'];?>
</a></li>
	<li><a href="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-server-download mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['serverbackups'];?>
</a></li>
	<li><a href="index.php?site=permexport&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-format-section-download mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['permexport'];?>
</a></li>
	<li><a href="index.php?site=clientsexport&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-multiple-download mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['clientsexport'];?>
</a></li>
	<li><a href="index.php?site=bansexport&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-off-download mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['bansexport'];?>
</a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['console'];?>
</li>
	<li><a href="index.php?site=console&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-console-line mdi-lg"></i> <?php echo $_smarty_tpl->getVariable('lang')->value['queryconsole'];?>
</a></li>
<?php }?>
<?php }?>