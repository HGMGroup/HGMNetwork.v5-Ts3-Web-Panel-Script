<?php /* Smarty version Smarty3rc4, created on 2018-02-05 01:47:12
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/mrstipfan/showupdate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:282275a77b7a05f3348-84511180%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '38c1d44cc2ae35200a16984abe8f5c3f5e99c66b' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/mrstipfan/showupdate.tpl',
      1 => 1513634812,
    ),
  ),
  'nocache_hash' => '282275a77b7a05f3348-84511180',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('newwiversion')->value)){?>
<div class="alert alert-warning">
	<?php echo $_smarty_tpl->getVariable('newwiversion')->value;?>

</div>
<?php }?>