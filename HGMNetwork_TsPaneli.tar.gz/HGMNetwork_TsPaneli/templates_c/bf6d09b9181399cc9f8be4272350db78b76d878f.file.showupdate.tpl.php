<?php /* Smarty version Smarty3rc4, created on 2020-04-22 01:12:00
         compiled from "C:\xampp\htdocs\htdocs\templates/mrstipfan/showupdate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13047641165e9f7dc0a69313-43078164%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bf6d09b9181399cc9f8be4272350db78b76d878f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\htdocs\\templates/mrstipfan/showupdate.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '13047641165e9f7dc0a69313-43078164',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('newwiversion')->value)){?>
<div class="alert alert-warning">
	<?php echo $_smarty_tpl->getVariable('newwiversion')->value;?>

</div>
<?php }?>