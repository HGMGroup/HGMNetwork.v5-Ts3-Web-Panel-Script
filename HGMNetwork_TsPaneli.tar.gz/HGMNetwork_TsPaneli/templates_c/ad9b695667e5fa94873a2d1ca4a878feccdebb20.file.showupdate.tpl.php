<?php /* Smarty version Smarty3rc4, created on 2018-02-05 02:15:35
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/46/showupdate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:150065a77be47da06e9-80091063%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ad9b695667e5fa94873a2d1ca4a878feccdebb20' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/46/showupdate.tpl',
      1 => 1501419068,
    ),
  ),
  'nocache_hash' => '150065a77be47da06e9-80091063',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('newwiversion')->value)){?>
<div class="alert alert-warning">
	<?php echo $_smarty_tpl->getVariable('newwiversion')->value;?>

</div>
<?php }?>